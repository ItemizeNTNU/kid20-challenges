import java.io.*;  
import java.util.*;
import java.math.BigInteger;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

class Manipulator {
    static {
        System.loadLibrary("string");
    }
    public static native String getString();

    public static void main(String[] args) {
        String alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789{_}";
        String flag = ????
        int num = 0;
        try {
            File myObj = new File("bits.txt");
            Scanner r = new Scanner(myObj);
            num = Integer.parseInt(r.nextLine(), 2)%255;
            r.close();
        } catch (FileNotFoundException e) {}

        String mid = flag.substring(6,flag.length()-1);
        for (int a=0; a<Math.pow(mid.length(),3)/4;a+=num){
            mid = a(mid.substring(0,a%mid.length()), alphabet) + mid.substring(a%mid.length());
            if(mid.codePointAt(0)%2==0){
                mid = mid.substring(0,1)+b(mid.substring(1));
            }
        }
        mid = a(mid, alphabet);
        
        String useThis = new Manipulator().getString();
        mid = d(mid, useThis, alphabet);
        flag = flag.substring(0,6) + mid + flag.substring(flag.length()-1);
        byte[] b = flag.getBytes(StandardCharsets.UTF_8);
        try {
            String out = "";
            for (int i=0;i<b.length;i++){
                out+=write(String.valueOf(i%2), b[i]);
            }
            FileWriter w = new FileWriter("output.txt");
            w.write(out);
            w.close();
        } catch (IOException e) {}
    }
    public static String a(String s, String alphabet) {
        String what = help(s);
        
        String newString = "";
        for(int i=0;i<s.length();i++){   
            newString += alphabet.charAt((alphabet.indexOf(what.charAt(i))+i)%alphabet.length());
        }
        return newString;   
    } 
    public static String b(String s){
        return new StringBuilder(s).reverse().toString(); 
    }
    
    public static String d(String a, String b, String alphabet) {
        String o = "";
        char[] ca = a.toCharArray();
        char[] cb = b.toCharArray();
        for (int i=0;i<ca.length;i++) {
            int posa = alphabet.indexOf(ca[i]);
            int posb = alphabet.indexOf(cb[i]);
            o += alphabet.charAt((posa+posb)%alphabet.length());
        }
        return o; 
    }  
    public static String help(String s){
        int middle = s.length()/2;
        String end = b(s.substring(0,middle));
        String start = b(s.substring(middle,s.length()));
        if(middle==1 || middle==0){
            return start+end;
        } else {
            return help(start)+help(end);
        }
            
    }
    public static String write(String val, int l){
        String ut="";
        for(int j=0;j<l;j++){
            ut+=val;
        }
        return ut;
    }

    
    
}

