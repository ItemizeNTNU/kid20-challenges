### OPENFAAS TEST REPO

This is my first repo for learning git and openfaas! :D
