﻿using System;
using System.Text;

namespace Function
{
    public class FunctionHandler
    {
        public string Handle(string input) {
            return $"Hi there - your input was: {input}\n";
        }
    }
}
